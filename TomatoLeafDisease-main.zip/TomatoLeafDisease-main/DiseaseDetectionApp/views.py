from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from PIL import Image as PILImage
from django.http import FileResponse
import io
from mmap import PAGESIZE
import tensorflow as tf
from django.shortcuts import render
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.image import load_img, img_to_array
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework import status
import numpy as np
import os
from django.conf import settings
import json
import logging
import shutil
from reportlab.lib.utils import ImageReader

# Explicitly import PIL to ensure it's available
try:
    from PIL import Image
except ImportError:
    raise ImportError("Pillow is not installed. Please run 'pip install Pillow' to use image processing features.")

# Set up logging
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Load the model
model_path = os.path.join(os.path.dirname(__file__), 'models', 'my_model.h5')
try:
    model = load_model(model_path)
    model.compile(optimizer="adam", loss="sparse_categorical_crossentropy", metrics=["accuracy"])
    logger.info(f"Model loaded successfully from {model_path}")
except FileNotFoundError:
    logger.error(f"Model file not found at {model_path}")
    model = None

# Class labels
class_labels = [
    'Tomato___Bacterial_spot',
    'Tomato___Early_blight',
    'Tomato___Late_blight',
    'Tomato___Leaf_Mold',
    'Tomato___Septoria_leaf_spot',
    'Tomato___Spider_mites Two-spotted_spider_mite',
    'Tomato___Target_Spot',
    'Tomato___Tomato_Yellow_Leaf_Curl_Virus',
    'Tomato___Tomato_mosaic_virus',
    'Tomato___healthy'
]


def index(request):
    return render(request, 'index.html')


# Prediction function
def Prediction(img):
    if model is None:
        raise ValueError("Model not loaded. Please check server configuration.")
    img_array = tf.keras.preprocessing.image.img_to_array(img)
    img_array = tf.expand_dims(img_array, 0)  # Create a batch
    predictions = model.predict(img_array)
    predicted_class = class_labels[np.argmax(predictions[0])]
    confidence = round(100 * np.max(predictions[0]), 2)
    return predicted_class, confidence



def generate_report(response_data, file_path):
    logger.info("Inside generate_report function — generating PDF now...")
    buffer = io.BytesIO()
    p = canvas.Canvas(buffer, pagesize=A4)
    width, height = A4
    margin = 50

    # 1. Title
    p.setFont("Helvetica-Bold", 20)
    p.drawCentredString(width / 2, height - margin, "AI Plant Disease Detection Report")
    p.setStrokeColor(colors.HexColor("#4CAF50"))
    p.setLineWidth(2)
    p.line(margin, height - margin - 10, width - margin, height - margin - 10)

    # 2. Image section
    image_top_y = height - margin - 60  # Title margin + spacing
    image_box_height = 150

    if os.path.exists(file_path):
        try:
            pil_img = PILImage.open(file_path)
            pil_img.thumbnail((image_box_height, image_box_height))
            img_io = io.BytesIO()
            pil_img.save(img_io, format="PNG")
            img_io.seek(0)
            image_reader = ImageReader(img_io)

            p.setFont("Helvetica-Bold", 13)
            p.setFillColor(colors.darkgreen)
            p.drawString(margin, image_top_y, "Uploaded Image:")
            p.setFillColor(colors.black)
            p.drawImage(image_reader, margin, image_top_y - image_box_height - 10,
                        width=image_box_height, height=image_box_height,
                        preserveAspectRatio=True, mask='auto')
        except Exception as e:
            p.setFont("Helvetica", 12)
            p.setFillColor(colors.red)
            p.drawString(margin, image_top_y - 20, f"Image Error: {e}")
            p.setFillColor(colors.black)

    # 3. Prediction summary (right box)
    box_x = width - margin - 260
    box_y = image_top_y - 20
    box_width = 260
    box_height = 90

    p.setFont("Helvetica-Bold", 13)
    p.setFillColor(colors.darkblue)
    p.drawString(box_x, box_y, "Prediction Summary")
    p.setFillColor(colors.black)
    p.setStrokeColor(colors.grey)
    p.setLineWidth(1)
    p.roundRect(box_x - 10, box_y - box_height, box_width, box_height, 10, stroke=1, fill=0)

    p.setFont("Helvetica", 12)
    p.drawString(box_x, box_y - 20, f"Disease: {response_data['predicted_label']}")
    p.drawString(box_x, box_y - 40, f"Confidence: {response_data['confidence_score']}")

    # 4. Prevention Section
    prevention_y = image_top_y - image_box_height - 60
    p.setFont("Helvetica-Bold", 13)
    p.setFillColor(colors.darkgreen)
    p.drawString(margin, prevention_y, "Prevention Methods")
    p.setFillColor(colors.black)

    p.setFont("Helvetica", 11)
    y = prevention_y - 20
    bullet = u"\u2022"
    for method in response_data['prevention']:
        p.drawString(margin + 15, y, f"{bullet} {method}")
        y -= 16
        if y < 100:
            p.showPage()
            y = height - margin
            p.setFont("Helvetica", 11)

    # 5. Footer Logo (Bottom-right corner)
    logo_path = os.path.join(settings.BASE_DIR, 'DiseaseDetectionApp', 'static', 'approved.png')
    if os.path.exists(logo_path):
        logo_width = 150
        logo_height = 150
        x_position = width - margin - logo_width
        y_position = margin - 10
        p.drawImage(logo_path, x_position, y_position, width=logo_width, height=logo_height,
                    preserveAspectRatio=False, mask='auto')
    else:
        logger.warning(f"Logo not found at path: {logo_path}")

    # Finalize PDF
    p.showPage()
    p.save()
    buffer.seek(0)

    return FileResponse(buffer, as_attachment=True, filename="Plant_Disease_Report.pdf", content_type='application/pdf')





class ReportPDFView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        if 'image_input' not in request.FILES:
            return Response({"error": "No image provided"}, status=400)

        uploaded_file = request.FILES['image_input']
        file_path = os.path.join(settings.MEDIA_ROOT, 'uploaded_images', uploaded_file.name)

        with open(file_path, 'wb') as f:
            for chunk in uploaded_file.chunks():
                f.write(chunk)

        try:
            with Image.open(file_path) as img:
                img.verify()
            img = load_img(file_path, target_size=(256, 256))

            predicted_class, confidence = Prediction(img)

            prevention_file_path = os.path.join(settings.BASE_DIR, 'DiseaseDetectionApp', 'prevention_methods.json')
            with open(prevention_file_path, 'r') as file:
                prevention_methods = json.load(file)

            prevention = prevention_methods.get(predicted_class, ["No prevention methods available."])

            response_data = {
                "predicted_label": predicted_class,
                "confidence_score": f"{confidence}%",
                "prevention": prevention
            }

            return generate_report(response_data, file_path)
        except Exception as e:
            return Response({"error": str(e)}, status=500)


# API View for Prediction
class PredictDiseaseAPIView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    
    def get(self, request, *args, **kwargs):
        logger.info(f"GET request from {request.META.get('REMOTE_ADDR')}")
        return Response({
            "status": "Server is running",
            "message": "Use POST with 'image_input' to predict disease",
            "model_loaded": model is not None
        }, status=status.HTTP_200_OK)



            

    def post(self, request, *args, **kwargs):

        logger.info(f"POST request from {request.META.get('REMOTE_ADDR')}")
        upload_dir = os.path.join(settings.MEDIA_ROOT, 'uploaded_images')
        os.makedirs(upload_dir, exist_ok=True)


        for filename in os.listdir(upload_dir):
            file_path = os.path.join(upload_dir, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)

            file_path = os.path.join(folder_path, filename)
            if os.path.isfile(file_path):
                os.remove(file_path)
        
        if 'image_input' not in request.FILES:
            logger.warning("No image provided in request")
            return Response({"error": "No image provided"}, status=status.HTTP_400_BAD_REQUEST)

        uploaded_file = request.FILES['image_input']
        logger.info(f"Received file: {uploaded_file.name}, size: {uploaded_file.size} bytes")
        
        
        file_path = os.path.join(upload_dir, uploaded_file.name)

        try:
            with open(file_path, 'wb') as f:
                for chunk in uploaded_file.chunks():
                    f.write(chunk)
            logger.info(f"File saved to {file_path}")

            # Verify the file is a valid image using PIL before processing
            try:
                with Image.open(file_path) as img:
                    img.verify()  # Check if it's a valid image
                img = load_img(file_path, target_size=(256, 256))  # Load with Keras
            except Exception as e:
                logger.error(f"Invalid image file: {str(e)}")
                raise ValueError(f"Invalid image file: {str(e)}")

            predicted_class, confidence = Prediction(img)

            prevention_file_path = os.path.join(settings.BASE_DIR, 'DiseaseDetectionApp', 'prevention_methods.json')
            with open(prevention_file_path, 'r') as file:
                prevention_methods = json.load(file)

            prevention = prevention_methods.get(predicted_class, ["No prevention methods available."])

            response_data = {
                "predicted_label": predicted_class,
                "confidence_score": f"{confidence}%",
                "prevention": prevention
            }
            
            



            logger.info(f"Prediction: {predicted_class}, Confidence: {confidence}%")
            os.remove(file_path)
            return Response(response_data, status=status.HTTP_200_OK)
        except Exception as e:
            logger.error(f"Error processing request: {str(e)}")
            if os.path.exists(file_path):
                os.remove(file_path)
            return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


def register(request):
    return render(request, 'register.html')

def login(request):
    return render(request, 'login.html')